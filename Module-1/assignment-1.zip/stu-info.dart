import 'dart:io';

void main() {
	const int totalStudents = 5;
	final List<Map<String, dynamic>> students = [];
	final Set<String> usedContactNumbers = {};

	print('=== Programming Club Student Information System ===');
	print('Please enter information for $totalStudents students.\n');

	for (int i = 1; i <= totalStudents; i++) {
		print('--- Student $i ---');

		stdout.write('Name: ');
		String name = stdin.readLineSync()?.trim() ?? '';
		if (name.isEmpty) {
			name = 'N/A';
		}

		stdout.write('Details/About: ');
		String details = stdin.readLineSync()?.trim() ?? '';
		if (details.isEmpty) {
			details = 'N/A';
		}

		stdout.write('Present Address: ');
		String presentAddress = stdin.readLineSync()?.trim() ?? '';
		if (presentAddress.isEmpty) {
			presentAddress = 'N/A';
		}

		stdout.write('Permanent Address: ');
		String permanentAddress = stdin.readLineSync()?.trim() ?? '';
		if (permanentAddress.isEmpty) {
			permanentAddress = 'N/A';
		}

		stdout.write('Contact Number: ');
		String contactNumber = stdin.readLineSync()?.trim() ?? '';
		if (contactNumber.isEmpty) {
			contactNumber = 'N/A';
		}

		if (usedContactNumbers.contains(contactNumber) && contactNumber != 'N/A') {
			print('Duplicate contact found, saved as N/A.');
			contactNumber = 'N/A';
		}
		usedContactNumbers.add(contactNumber);

		stdout.write('Age: ');
		String ageInput = stdin.readLineSync()?.trim() ?? '';
		int age = int.tryParse(ageInput) ?? 0;

		final Map<String, dynamic> student = {
			'Name': name,
			'Details/About': details,
			'Present Address': presentAddress,
			'Permanent Address': permanentAddress,
			'Contact Number': contactNumber,
			'Age': age,
		};

		students.add(student);
		print('Student $i information saved.\n');
	}

	print('\n=== All Stored Student Information ===');
	for (int i = 0; i < students.length; i++) {
		print('\nStudent ${i + 1}:');
		print('Name: ${students[i]['Name']}');
		print('Details/About: ${students[i]['Details/About']}');
		print('Present Address: ${students[i]['Present Address']}');
		print('Permanent Address: ${students[i]['Permanent Address']}');
		print('Contact Number: ${students[i]['Contact Number']}');
		print('Age: ${students[i]['Age']}');
	}

	print('\nInput complete. Program stopped after $totalStudents students.');
}